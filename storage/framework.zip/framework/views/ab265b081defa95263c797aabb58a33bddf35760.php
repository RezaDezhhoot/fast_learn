<?php foreach($attributes->onlyProps(['title','link','icon','active']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title','link','icon','active']); ?>
<?php foreach (array_filter((['title','link','icon','active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li class="<?php echo e($active ? 'page-active' : ''); ?> ">
    <a href="<?php echo e($link); ?>"> <i class="<?php echo e($icon); ?> la-2x" ></i><?php echo e($title); ?> </a>
</li>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/client/sidebar-link.blade.php ENDPATH**/ ?>