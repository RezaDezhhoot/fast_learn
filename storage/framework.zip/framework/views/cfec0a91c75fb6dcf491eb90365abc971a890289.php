<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.site.breadcrumbs','data' => ['data' => $page_address,'title' => 'مقالات اموزشی']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page_address),'title' => 'مقالات اموزشی']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <section class="course-area">
        <div class="container">
            <div class="filter-bar mb-4">
                <div class="filter-bar-inner d-flex flex-wrap align-items-center justify-content-between">
                    <p class="fs-14">ما <span class="text-black"><?php echo e($articles->count()); ?></span> مقاله برای شما پیدا
                        کردیم</p>
                    <div class="d-flex flex-wrap align-items-center">
                    </div>
                </div>
                <!-- end filter-bar-inner -->
            </div>
            <!-- end filter-bar -->
            <div class="row">
                <div class="col-lg-3" wire:ignore>
                    <div class="sidebar mb-5">
                        <div class="card card-item">
                            <div class="card-body">
                                <h3 class="card-title fs-18 pb-2">فیلد جستجو</h3>
                                <div class="divider"><span></span></div>
                                <form wire:submit.prevent="search">
                                    <div class="form-group mb-0">
                                        <input wire:model.defer="q" class="form-control form--control pl-3"
                                            type="text" name="q" placeholder="جستجوی مقاله" />
                                        <span wire:click="search" class="la la-search search-icon"></span>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card card-item">
                            <div class="card-body">
                                <h3 class="card-title fs-18 pb-2">دسته بندی ها</h3>
                                <div class="divider"><span></span></div>
                                <div class="custom-control custom-checkbox mb-1 fs-15">
                                    <input type="radio" name="category" class="custom-control-input"
                                        wire:model="category" value="" id="all_categories" required="" />
                                    <label class="custom-control-label custom--control-label text-black"
                                        for="all_categories"> همه دسته بندی ها </label>
                                </div>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-checkbox mb-1 fs-15">
                                    <input type="radio" name="category" wire:model="category"
                                        value="<?php echo e($item['slug']); ?>" class="custom-control-input"
                                        id="<?php echo e($item['slug']); ?>" required="" />
                                    <label class="custom-control-label custom--control-label text-black"
                                        for="<?php echo e($item['slug']); ?>"> <?php echo e($item['title']); ?> </label>
                                    <?php if(!empty($item['sub_categories'])): ?>
                                    <?php $__currentLoopData = $item['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-control custom-checkbox mb-1 fs-15">
                                        <input type="radio" name="category" wire:model="category" value="<?php echo e($value); ?>"
                                            class="custom-control-input" id="<?php echo e($value); ?>" required="" />
                                        <label class="custom-control-label custom--control-label text-black"
                                            for="<?php echo e($value); ?>"> <span
                                                class="text-gray"><?php echo e($item['sub_categories_title'][$key]); ?></span>
                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end sidebar -->
                </div>
                <!-- end col-lg-4 -->
                <div class="col-lg-9">
                    <?php if(sizeof($articles)): ?>
                    <div class="row">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 responsive-column-half">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.site.articles.article-box','data' => ['item' => $item]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.articles.article-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- end row -->

                    <?php else: ?>
                    <div class="text-center mb-3">
                        <img class="mx-auto no-date d-block mt-5" src="<?php echo e(asset('site/svg/No-data-cuate.svg')); ?>"
                            alt="">
                        <h5 class="mt-3">ما هیچ مقاله ای برای شما پیدا نکردیم!</h5>
                    </div>
                    <?php endif; ?>
                    <?php echo e($articles->links('site.includes.paginate')); ?>

                </div>
                <!-- end col-lg-8 -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </section>
</div><?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/site/articles/index-article.blade.php ENDPATH**/ ?>