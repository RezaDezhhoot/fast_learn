<?php foreach($attributes->onlyProps(['id', 'label', 'type' , 'required' => false ,'disabled' => false ,'help' => false,'with' => 12]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'label', 'type' , 'required' => false ,'disabled' => false ,'help' => false,'with' => 12]); ?>
<?php foreach (array_filter((['id', 'label', 'type' , 'required' => false ,'disabled' => false ,'help' => false,'with' => 12]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="form-group col-12 col-md-<?php echo e($with); ?>">
    <label for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
    <input  <?php echo $attributes->merge(['class'=> 'form-control']); ?> <?php echo e($disabled ? 'disabled' : ''); ?> type="<?php echo e($type); ?>" id="<?php echo e($id); ?>" <?php echo e($attributes); ?>>
    <?php if($help): ?>
        <small class="text-info"><?php echo e($help); ?></small>
    <?php endif; ?>
    <?php $__errorArgs = [$id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger d-block"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/admin/forms/input.blade.php ENDPATH**/ ?>