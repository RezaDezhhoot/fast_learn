<div wire:init="loadCourse">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.site.courses.breadcrumbs','data' => ['data' => $page_address,'course' => $course]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.courses.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page_address),'course' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <section class="course-details-area pb-20px">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 pb-5">
                    <div class="course-dashboard-column w-100 pt-5">
                        <div class="lecture-viewer-container col-12 p-0">
                            <div class="lecture-video-item col-12  p-0" id="videoContent">
                                <?php if(!is_null($api_bucket)): ?>
                                <div class="col-12 p-0">
                                    <?php echo $api_bucket; ?>

                                </div>
                                <div class="mt-2">
                                    <button class="btn btn-outline-primary"
                                        onclick="back_to_episode('heading<?php echo e($episode_id); ?>')">بازگشت به درس</button>
                                </div>
                                <?php elseif(!is_null($local_video)): ?>
                                <div
                                    class="plyr plyr--full-ui plyr--video plyr--html5 plyr--fullscreen-enabled plyr--paused">
                                    <video id="player" class="player" playsinline controls
                                        data-poster="<?php echo e(asset($course->image)); ?>">

                                    </video>
                                </div>

                                <div class="mt-2">
                                    <button class="btn btn-outline-primary"
                                        onclick="back_to_episode('heading<?php echo e($episode_id); ?>')">بازگشت به درس</button>
                                </div>
                                <?php else: ?>
                                <img src="<?php echo e(asset($course->image)); ?>" class="col-12  p-0" alt="<?php echo e($course->title); ?>">
                                <?php endif; ?>
                                <p class="text-info" wire:loading> در حال دریافت... </p>
                            </div>
                        </div>
                    </div>

                    <div class="course-details-content-wrap mt-5">
                        <?php echo $course->long_body; ?>

                        <div class="course-overview-card">
                            <div class="curriculum-header d-flex align-items-center justify-content-between pb-4">
                                <h3 class="fs-24 font-weight-semi-bold">محتوای دوره</h3>
                                <div class="curriculum-duration fs-15">
                                    <span class="curriculum-total__text mr-2"><strong
                                            class="text-black font-weight-semi-bold">مجموع:</strong> <?php echo e($course->episodes->count()); ?> مبحث </span>
                                    <span class="curriculum-total__hours"><strong
                                            class="text-black font-weight-semi-bold">کل ساعت:</strong> <?php echo e($course->time); ?></span>
                                </div>
                            </div>
                            <div class="curriculum-content">

                                <div id="accordion" class="generic-accordion" wire:ignore>
                                    <?php if(sizeof($episodes) > 0): ?>
                                    <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card">
                                        <div class="card-header" id="heading<?php echo e($item['id']); ?>">
                                            <button
                                                class="btn btn-link d-flex align-items-center justify-content-between"
                                                data-toggle="collapse" data-target="#collapse<?php echo e($item->id); ?>"
                                                aria-expanded="<?php echo e($key == 0 ? 'true' : 'false'); ?>"
                                                aria-controls="collapse<?php echo e($item->id); ?>">
                                                <i class="la la-plus"></i>
                                                <i class="la la-minus"></i>
                                                <p>
                                                    <small class="episode_counter"><?php echo e($loop->iteration); ?></small>
                                                    <?php echo e($item['title']); ?>

                                                </p>

                                                <?php if($item['free'] || $course->price == 0): ?>
                                                <small class="text-success">رایگان <i class="la la-lock-open">
                                                    </i></small>
                                                <?php elseif(auth()->check() && $user->hasCourse($course->id)): ?>
                                                <small class="text-success">خریداری شده <i class="la la-lock-open">
                                                    </i></small>
                                                <?php elseif(!auth()->check() || (auth()->check() &&
                                                !$user->hasCourse($course->id))): ?>
                                                <div class="text-left">
                                                    <small class="text-danger">نقدی <i class="la la-lock">
                                                        </i></small>
                                                </div>
                                                <?php endif; ?>
                                            </button>
                                        </div>
                                        <!-- end card-header -->

                                        <div id="collapse<?php echo e($item->id); ?>" class="collapse <?php echo e($key == 0 ? 'show' : ''); ?>"
                                            aria-labelledby="heading<?php echo e($item->id); ?>" data-parent="#accordion">
                                            <?php if(auth()->check()): ?>
                                            <?php if((($item['free'] || $course->price == 0) ||
                                            ($user->hasCourse($course->id)))): ?>
                                            <div class="card-body pt-2">
                                                <?php if(!empty($item->description)): ?>
                                                <p class="px-0 text-black">
                                                    <i class="la la-star mr-1"></i>
                                                    <?php echo e($item->description); ?>

                                                </p>
                                                <?php endif; ?>
                                                <hr>
                                                <ul class="generic-list-item">
                                                    <?php if(!empty($item['api_bucket']) && $item['show_api_video'] ): ?>
                                                    <li>
                                                        <a class="d-flex align-items-center justify-content-between"
                                                            data-toggle="modal" data-target="#previewModal">
                                                            <span
                                                                wire:click="set_content('api_bucket','<?php echo e($item['id']); ?>')"
                                                                class="cursor-pointers showVideo">
                                                                <i class="la la-play-circle mr-1"></i>
                                                                نمایش ویدئو
                                                            </span>
                                                            <span><?php echo e($item['time']); ?></span>
                                                        </a>
                                                    </li>

                                                    <?php elseif(!empty($item['local_video'])): ?>
                                                    <?php if($item['allow_show_local_video']): ?>
                                                    <li>
                                                        <a class="d-flex align-items-center justify-content-between"
                                                            data-toggle="modal" data-target="#previewModal">
                                                            <span
                                                                wire:click="set_content('show_local_video','<?php echo e($item['id']); ?>')"
                                                                class="cursor-pointers showVideo">
                                                                <i class="la la-play-circle mr-1"></i>
                                                                نمایش ویدئو
                                                            </span>
                                                            <span><?php echo e($item['time']); ?></span>
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>

                                                    <?php if($item['downloadable_local_video']): ?>
                                                    <li>
                                                        <a class="d-flex align-items-center justify-content-between"
                                                            data-toggle="modal" data-target="#previewModal">
                                                            <span
                                                                wire:click="set_content('local_video','<?php echo e($item['id']); ?>')"
                                                                class="cursor-pointers">
                                                                <i class="la la-download mr-1"></i>
                                                                دانلود ویدئو
                                                            </span>
                                                        </a>
                                                    </li>

                                                    <?php endif; ?>

                                                    <?php endif; ?>
                                                    <?php if(!empty($item['file'])): ?>
                                                    <li>
                                                        <a class="d-flex align-items-center justify-content-between"
                                                            data-toggle="modal" data-target="#previewModal">
                                                            <span wire:click="set_content('file','<?php echo e($item['id']); ?>')"
                                                                class="cursor-pointers">
                                                                <i class="la la-file mr-1"></i>
                                                                دانلود فایل
                                                            </span>

                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php if(!empty($item['link']) ): ?>
                                                    <li>
                                                        <a class="d-flex align-items-center justify-content-between"
                                                            data-toggle="modal" data-target="#previewModal">
                                                            <span wire:click="set_content('link','<?php echo e($item['id']); ?>')"
                                                                class="cursor-pointers">
                                                                <i class="la la-link mr-1"></i>
                                                                لینک
                                                            </span>

                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php if($item->can_homework): ?>
                                                    <li data-toggle="modal" data-target="#homeworkModal">
                                                        <a class="d-flex align-items-center justify-content-between"
                                                            data-toggle="modal" data-target="#previewModal">
                                                            <span wire:click="homework('<?php echo e($item['id']); ?>')"
                                                                class="cursor-pointers">
                                                                <i class="la la-file-import mr-1"></i>
                                                                ارسال تمرین
                                                            </span>

                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                    <small class="text-info" wire:loading>
                                                        در حال دریافت ...
                                                    </small>
                                                </ul>
                                            </div>
                                            <?php else: ?>
                                            <p class="alert alert-danger">دوره خریداری نشده است.</p>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <p class="alert alert-info">دسترسی به این بخش نیاز به ثبت نام دارد.</p>
                                            <?php endif; ?>
                                        </div>
                                        <!-- end collapse -->
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <p class="alert alert-info">
                                        هنوز هیچ درسی منتشر نشده است.
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <!-- end generic-accordion -->
                            </div>
                            <!-- end curriculum-content -->
                        </div>
                        <!-- end course-overview-card -->
                        <?php if(!is_null($course->teacher)): ?>
                        <div class="course-overview-card pt-4">
                            <h3 class="fs-24 font-weight-semi-bold pb-4">در مورد مربی</h3>
                            <div class="instructor-wrap">
                                <div class="media media-card">
                                    <div class="instructor-img">
                                        <a href="<?php echo e(route('teacher',$course->teacher->user->id)); ?>"
                                            class="media-img d-block">
                                            <img class="lazy" src="<?php echo e(asset($course->teacher->user->image)); ?>"
                                                data-src="<?php echo e(asset($course->teacher->user->image)); ?>"
                                                alt="<?php echo e($course->teacher->user->name); ?>" />
                                        </a>
                                        <ul class="generic-list-item pt-3">
                                            <li><i class="la la-user mr-2 text-color-3"></i> <?php echo e($course->teacher->user->students_count); ?> دانش آموز </li>
                                            <li><i class="la la-comment-o mr-2 text-color-3"></i> <?php echo e(number_format($course->teacher->user->comments_count)); ?> نظر</li>
                                            <li><i class="la la-play-circle-o mr-2 text-color-3"></i> <?php echo e($course->teacher->user->course_count); ?> دوره</li>
                                            <li><a
                                                    href="<?php echo e(route('courses',['teacher'=>$course->teacher->user->code])); ?>">مشاهده
                                                    تمام دوره ها</a></li>
                                        </ul>
                                    </div>
                                    <!-- end instructor-img -->
                                    <div class="media-body">
                                        <h5><a href="<?php echo e(route('teacher',$course->teacher->id)); ?>"><?php echo e($course->teacher->user->name); ?></a></h5>
                                        <span class="d-block lh-18 pt-2 pb-3"> شروع فعالیت از <?php echo e($course->teacher->created_at->diffForHumans()); ?> </span>
                                        <p class="pb-3">
                                            <?php echo $course->teacher->body; ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- end instructor-wrap -->
                        </div>
                        <?php endif; ?>
                        <!-- end course-overview-card -->
                        <?php if(auth()->guard()->check()): ?>
                        <div class="course-overview-card pt-4">
                            <h3 class="fs-24 font-weight-semi-bold pb-4"><?php echo e($actionLabel); ?></h3>
                            <form method="post" id="commentForm" class="row" wire:submit.prevent="new_comment">
                                <?php if(auth()->guard()->check()): ?>
                                <div class="input-box col-lg-12">
                                    <label class="label-text">پیام</label>
                                    <div class="form-group">
                                        <textarea wire:model.defer="comment" class="form-control form--control pl-3"
                                            name="message" placeholder="پیام بنویس" rows="5"></textarea>
                                    </div>
                                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-box col-lg-12 text-right overflow-hidden mb-3">
                                    <div class="g-recaptcha d-inline-block"
                                        data-sitekey="<?php echo e(config('services.recaptcha.site_key')); ?>"
                                        data-callback="reCaptchaCallback" wire:ignore></div>
                                    <?php $__errorArgs = ['recaptcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback d-block"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="btn-box col-lg-12">
                                    <!-- end custom-control -->
                                    <button class="btn theme-btn" type="submit">ارسال دیدگاه</button>
                                </div>
                                <?php else: ?>
                                <p class="text-info">
                                    برای ثبت دیدگاه ابتدا ثبت نام کنید
                                </p>
                                <?php endif; ?>
                                <!-- end btn-box -->
                            </form>
                        </div>
                        <?php else: ?>
                        <p class="text-info">
                            برای ثبت دیدگاه ابتدا ثبت نام کنید
                        </p>
                        <?php endif; ?>
                        <div class="course-overview-card pt-4">
                            <h3 class="fs-24 font-weight-semi-bold pb-4">پرسش و پاسخ</h3>
                            <div class="review-wrap">
                                <?php if(sizeof($comments) > 0): ?>
                                <?php for($i=0;$i<$commentCount ;$i++): ?> <?php if(isset($comments[$i])): ?> <div
                                    class="media media-card shadow-sm p-3 mb-4 bg-white rounded pb-4 mb-1">
                                    <div class="media-img mr-4 rounded-full">
                                        <img class="rounded-full lazy" src="<?php echo e(asset($comments[$i]->user->image)); ?>"
                                            data-src="<?php echo e(asset($comments[$i]->user->image)); ?>"
                                            alt="<?php echo e($comments[$i]->user->name); ?>" />
                                    </div>
                                    <div class="media-body">
                                        <div class="d-flex flex-wrap align-items-center justify-content-between pb-1">
                                            <h5><?php echo e($comments[$i]->user->name); ?> <?php echo e($comments[$i]->user->id ==
                                                $course->teacher->id ? " (مدرس) " : ''); ?></h5>
                                        </div>
                                        <span class="d-block lh-18 py-2"><?php echo e($comments[$i]->created_at->diffForHumans()); ?></span>
                                        <p class="pb-2">
                                            <?php echo $comments[$i]->content; ?>

                                        </p>
                                        <div class="helpful-action">
                                            <button wire:click="$set('actionComment',<?php echo e($comments[$i]->id); ?>)"
                                                class="btn btn-outline-success goToCommentForm">پاسخ</button>
                                        </div>
                                    </div>
                            </div>
                            <?php $__currentLoopData = $comments[$i]->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="media media-card pb-4 shadow-sm p-3 mb-5 bg-white rounded p-3 mb-4 review-reply">
                                <div class="media-img mr-4 rounded-full">
                                    <img class="rounded-full lazy" src="<?php echo e(asset($value->user->image)); ?>"
                                        data-src="<?php echo e(asset($value->user->image)); ?>" alt="<?php echo e($value->user->name); ?>" />
                                </div>
                                <div class="media-body">
                                    <div class="d-flex flex-wrap align-items-center justify-content-between pb-1">
                                        <h5><?php echo e($value->user->name); ?> <?php echo e($value->user->id == $course->teacher->id ? "
                                            (مدرس) " : ''); ?></h5>
                                    </div>
                                    <span class="d-block lh-18 py-2"><?php echo e($value->created_at->diffForHumans()); ?></span>
                                    <p class="pb-2">
                                        <?php echo $value->content; ?>

                                    </p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i != count($comments) - 1): ?>
                            <hr>
                            <?php endif; ?>
                            <?php endif; ?>

                            <?php endfor; ?>
                            <?php else: ?>
                            <p class="alert alert-info">
                                هیچ پرسش و پاسخی ثبت نشده است
                            </p>
                            <?php endif; ?>

                            <!-- end media -->
                        </div>
                        <!-- end review-wrap -->
                        <div class="see-more-review-btn text-center">
                            <?php if($commentCount < count($comments)): ?>
                                <button type="button" wire:click="moreComment()"
                                    class="btn theme-btn theme-btn-transparent">بارگیری نظرات بیشتر</button>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!-- end course-details-content-wrap -->
            </div>
            <!-- end col-lg-8 -->
            <div class="col-lg-4">
                <div class="sidebar sidebar-negative">
                    <div class="card card-item">
                        <div class="card-body">
                            <div class="preview-course-feature-content pt-1 mb-">
                                <div class="">
                                    <?php if($course->has_reduction && $course->base_price > 0): ?>
                                    <div class="m-0 p-0">
                                        <p class="before-price mx-1"> <?php echo e(number_format($course->base_price)); ?> </p>
                                        <?php if($course->price > 0): ?>
                                        <span class="fs-35 font-weight-semi-bold text-black"><?php echo e(number_format($course->price)); ?> تومان</span>
                                        <?php else: ?>
                                        <span class="fs-35 font-weight-semi-bold text-black">رایگان</span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="price-discount p-1"><?php echo e($course->reduction_percent); ?> درصد تخفیف</p>
                                    <?php if(!empty($course->expire_at)): ?>
                                    <p class="preview-price-discount-text pt-4"><span class="text-color-3"><?php echo e($course->expire_at->diffForHumans()); ?></span> با این قیمت!</p>
                                    <?php endif; ?>
                                    <?php elseif($course->base_price == 0 || $course->price == 0): ?>
                                    <span class="fs-35 font-weight-semi-bold text-black">رایگان</span>
                                    <?php else: ?>
                                    <span class="fs-35 font-weight-semi-bold text-black"><?php echo e(number_format($course->price)); ?> تومان</span>
                                    <?php endif; ?>
                                </div>
                                <div class="buy-course-btn-box mt-4">
                                    <?php if($course->price == 0): ?>
                                    <?php if(auth()->check() && $user->hasCourse($course->id)): ?>
                                    <button disabled type="button" class="btn btn-outline-success w-100 mb-2">شما در این دوره ثبت نام کرده اید</button>
                                    <?php else: ?>
                                    <button wire:click="getFreeOrder()" type="button" class="btn theme-btn w-100 mb-2"><i
                                        class="la la-shopping-cart fs-18 mr-1"></i> ثبت
                                    نام در این دوره</button>
                                    <?php endif; ?>

                                    <?php else: ?>
                                    <button wire:click="addToCart()" type="button" class="btn theme-btn w-100 mb-2"><i
                                            class="la la-shopping-cart fs-18 mr-1"></i> به سبد خرید اضافه کنید</button>
                                    <?php endif; ?>

                                </div>
                                <div class="preview-course-incentives">
                                    <h3 class="card-title fs-18 mt-2 pb-2">این دوره شامل</h3>
                                    <ul class="generic-list-item pb-3">
                                        <li><i class="la la-play-circle-o mr-2 text-color"></i><?php echo e($course->hours); ?> ساعت
                                            ویدیو اموزشی </li>
                                        <li><i class="la la-key mr-2 text-color"></i>دسترسی کامل مادام العمر</li>
                                    </ul>
                                </div>
                                <!-- end preview-course-incentives -->
                            </div>
                            <!-- end preview-course-content -->
                        </div>
                    </div>
                    <!-- end card -->
                    <div class="card card-item">
                        <div class="card-body">
                            <h3 class="card-title fs-18 pb-2">ویژگی های دوره</h3>
                            <div class="divider"><span></span></div>
                            <ul class="generic-list-item generic-list-item-flash">
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-clock mr-2 text-color"></i>مدت زمان</span> <?php echo e($course->time); ?>

                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-circle mr-2 text-color"></i>وضعیت </span> <?php echo e($course->status_label); ?>

                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-bolt mr-2 text-color"></i>امتحان</span> <?php echo e(!is_null($course->quiz) ? 'بعله' : 'خیر'); ?>

                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-eye mr-2 text-color"></i>درس ها</span> <?php echo e($course->episodes->count()); ?>

                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-lightbulb mr-2 text-color"></i>سطح دوره</span> <?php echo e($course->level_label); ?>

                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-gear mr-2 text-color"></i>نوع دوره</span> <?php echo e($course->type_label); ?>

                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <span><i class="la la-certificate mr-2 text-color"></i>گواهی</span> <?php echo e((!is_null($course->quiz) && !is_null($course->quiz->certificate)) ? 'بعله' : 'خیر'); ?>

                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- end card -->
                    <div class="card card-item">
                        <div class="card-body">
                            <h3 class="card-title fs-18 pb-2">دوره های مرتبط</h3>
                            <div class="divider"><span></span></div>
                            <?php $__currentLoopData = $related_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media media-card border-bottom border-bottom-gray pb-4 mb-4">
                                <a href="<?php echo e(route('course',$item->slug)); ?>" class="media-img">
                                    <img class="mr-3 lazy" src="<?php echo e(asset($item->image)); ?>"
                                        data-src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->title); ?>" />
                                </a>
                                <div class="media-body">
                                    <h5 class="fs-15"><a href="<?php echo e(route('course',$item->slug)); ?>"><?php echo e($item->title); ?></a>
                                    </h5>
                                    <span class="d-block lh-18 py-1 fs-14"><?php echo e($item->teacher->name); ?></span>
                                    <p class="text-black font-weight-semi-bold lh-18 fs-15"><?php echo e($item->price >0 ?
                                        number_format($item->price).' تومان' : 'رایگان'); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- end media -->
                            <div class="view-all-course-btn-box">
                                <a href="<?php echo e(route('courses')); ?>" class="btn theme-btn w-100">مشاهده همه دوره ها <i
                                        class="la la-arrow-left icon ml-1"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- end card -->
                    <div class="card card-item">
                        <div class="card-body">
                            <h3 class="card-title fs-18 pb-2">برچسب های دوره</h3>
                            <div class="divider"><span></span></div>
                            <ul class="generic-list-item generic-list-item-boxed d-flex flex-wrap fs-15">
                                <?php $__currentLoopData = $course->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mr-2"><a href="<?php echo e(route('courses',['q' => $item->name])); ?>"> <?php echo e($item->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end sidebar -->
            </div>
            <!-- end col-lg-4 -->
        </div>
        <!-- end row -->
</div>
<!-- end container -->
</section>

<div wire:ignore.self class="modal fade modal-container" id="homeworkModal" tabindex="-1" role="dialog"
    aria-labelledby="homeworkModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header border-bottom-gray d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <h5 class="modal-title fs-19 font-weight-semi-bold" id="shareModalTitle">ارسال تمرین</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="نزدیک">
                        <span aria-hidden="true" class="la la-times"></span>
                    </button>
                </div>
                <div>
                    <?php if(!is_null($homework) && empty($homework->result)): ?>
                    <button class="btn btn-sm btn-outline-danger" onclick="delete_homework()"><i
                            class="la la-trash"></i> حذف این تمرین</button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-body">
                <?php if($show_homework_form): ?>
                <form wire:submit.prevent="submit_homework()">
                    <div class="row">
                        <?php if(auth()->guard()->check()): ?>
                        <div class="input-box col-12">
                            <div class="form-group">
                                <div x-data="{ isUploading: false, progress: 0 }"
                                    x-on:livewire-upload-start="isUploading = true"
                                    x-on:livewire-upload-finish="isUploading = false"
                                    x-on:livewire-upload-error="isUploading = false"
                                    x-on:livewire-upload-progress="progress = $event.detail.progress"
                                    class="custom-file my-4">
                                    <input <?php echo e(!is_null($homework) ? 'disabled' : ''); ?> type="file"
                                        class="custom-file-input" wire:model="homework_file" id="homework_file">
                                    <label class="custom-file-label" for="homework_file">انتخاب فایل</label>
                                    <div class="mt-2" x-show="isUploading">
                                        در حال اپلود فایل...
                                        <progress max="100" x-bind:value="progress"></progress>
                                    </div>
                                    <small class="text-info">حداقل حجم مجاز : 2 مگابایت</small>
                                    <small class="text-info">jpg,jpeg,png,pdf,zip,rar</small>
                                    <?php if(!is_null($homework) && !is_null($homework->file)): ?>
                                    <small class="alert d-block p-1 alert-success">فایل ارسال شده است</small>
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['homework_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="input-box col-lg-12">
                            <label class="label-text">توضیحات</label>
                            <div class="form-group">
                                <textarea <?php echo e(!is_null($homework) ? 'disabled' : ''); ?>

                                    wire:model.defer="homework_description" class="form-control form--control pl-3"
                                    name="homework_description" placeholder="توضیحات" rows="5"></textarea>
                            </div>
                            <?php $__errorArgs = ['homework_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div
                            class="input-box col-lg-12 text-right overflow-hidden mb-3">
                            <div class="g-recaptcha d-inline-block"
                                data-sitekey="<?php echo e(config('services.recaptcha.site_key')); ?>"
                                data-callback="homeworkReCaptchaCallback" wire:ignore></div>
                            <?php $__errorArgs = ['homework_recaptcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback d-block"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="btn-box col-lg-12 <?php echo e(!is_null($homework) ? 'd-none' : ''); ?>">
                            <button <?php echo e(!is_null($homework) ? 'disabled' : ''); ?> class="btn theme-btn"
                                type="submit">ارسال تمرین</button>
                        </div>
                        <?php if(!is_null($homework) && !is_null($homework->result)): ?>
                        <div class="col-12">
                            <h6>نتیجه :</h6>
                            <small>
                                <?php for($i=1; $i<=5; $i++): ?> <?php if($i <=$homework->score): ?>
                                    <span class="la la-star"></span>
                                    <?php else: ?>
                                    <span class="la la-star-o"></span>
                                    <?php endif; ?>
                                    <?php endfor; ?>
                            </small>
                            <p class="mr-1">
                                <?php echo $homework->result; ?>

                            </p>
                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <p class="text-info">
                            برای ارسال تمرین ابتدا ثبت نام کنید
                        </p>
                        <?php endif; ?>
                    </div>
                </form>
                <?php else: ?>
                <p class="alert alert-danger">شما به این بخش دسترسی ندارید.</p>
                <?php endif; ?>
            </div>
            <div class="modal-footer justify-content-center border-top-gray">

            </div>
        </div>
    </div>
</div>
<div class="modal fade modal-container" id="shareModal" tabindex="-1" role="dialog" aria-labelledby="shareModalTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header border-bottom-gray">
                <h5 class="modal-title fs-19 font-weight-semi-bold" id="shareModalTitle">این دوره را به اشتراک بگذارید
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="نزدیک">
                    <span aria-hidden="true" class="la la-times"></span>
                </button>
            </div>
            <!-- end modal-header -->
            <div class="modal-body">
                <div class="copy-to-clipboard">
                    <span class="success-message">کپی شده!</span>
                    <div class="input-group">
                        <input type="text" class="form-control form--control copy-input pl-3"
                            value="<?php echo e(route('codes',$course->short_code)); ?>" />
                        <div class="input-group-append">
                            <button class="btn theme-btn theme-btn-sm copy-btn shadow-none"><i
                                    class="la la-copy mr-1"></i> کپی</button>
                        </div>
                    </div>
                </div>
                <!-- end copy-to-clipboard -->
            </div>
            <!-- end modal-body -->
            <div class="modal-footer justify-content-center border-top-gray">
                <ul class="social-icons social-icons-styled">
                    <li>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('codes',$course->short_code)); ?>"
                            class="facebook-bg"><i class="la la-facebook"></i></a>
                    </li>
                    <li>
                        <a href="https://twitter.com/intent/tweet?text=<?php echo e(route('codes',$course->short_code)); ?>"
                            class="twitter-bg"><i class="la la-twitter"></i></a>
                    </li>
                    <li>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(route('codes',$course->short_code)); ?>"
                            class="linkedin-bg"><i class="la la-linkedin"></i></a>
                    </li>
                </ul>
            </div>
            <!-- end modal-footer -->
        </div>
        <!-- end modal-content-->
    </div>
    <!-- end modal-dialog -->
</div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
    function delete_homework() {
            Swal.fire({
                title: 'حذف تمرین!',
                text: 'آیا از حذف این تمرین اطمینان دارید؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'خیر',
                confirmButtonText: 'بله'
            }).then((result) => {
                if (result.value) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').call('delete_homework')
                }
            })
        }
        function homeworkReCaptchaCallback(response) {
            window.livewire.find('<?php echo e($_instance->id); ?>').set('homework_recaptcha', response);
        }

        function reCaptchaCallback(response) {
            window.livewire.find('<?php echo e($_instance->id); ?>').set('recaptcha', response);
        }

        function back_to_episode(id)
        {
            $('html, body').animate({
                scrollTop: $(`#${id}`).offset().top
            }, 1000);
        }

        Livewire.on('resetReCaptcha', () => {
            grecaptcha.reset();
        });

        Livewire.on('loadRecaptcha', () => {
            const script = document.createElement('script');

            script.setAttribute('src', 'https://www.google.com/recaptcha/api.js');

            const start = document.createElement('script');


            document.body.appendChild(script);
            document.body.appendChild(start);
        });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/site/courses/single-course.blade.php ENDPATH**/ ?>