<?php foreach($attributes->onlyProps(['data','title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['data','title']); ?>
<?php foreach (array_filter((['data','title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<section class="breadcrumb-area py-5">
    <div class="container">
        <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
            <div class="section-heading">
                <h2 class="section__title text-black">
                    <?php echo e($title); ?>

                </h2>
            </div>
            <ul class="generic-list-item generic-list-item-black generic-list-item-arrow d-flex flex-wrap align-items-center">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a  <?php echo e(!empty($item['link']) ? "href=".$item['link']." " : " "); ?> class="font-12 vazir"><?php echo e($item['label']); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <!-- end breadcrumb-content -->
    </div>
    <!-- end container -->
</section>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/breadcrumbs.blade.php ENDPATH**/ ?>