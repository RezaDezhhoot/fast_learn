<?php foreach($attributes->onlyProps(['cartContent']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['cartContent']); ?>
<?php foreach (array_filter((['cartContent']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if(sizeof($cartContent) > 0): ?>
    <ul class="cart-dropdown-menu after-none">
        <?php $__currentLoopData = $cartContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="media media-card">
                <a class="media-img">
                    <img class="mr-3" src="<?php echo e(asset($item->image)); ?>" alt="تصویر سبد خرید" />
                </a>
                <div class="media-body">
                    <h5><?php echo e($item->title); ?></h5>
                    <p class="text-black font-weight-semi-bold lh-18"><?php echo e(number_format($item->total())); ?> تومان </p>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="media media-card">
            <div class="media-body fs-16">
                <p class="text-black font-weight-semi-bold lh-18"> مجموع: <?php echo e(number_format(App\Http\Controllers\Cart\Facades\Cart::price()-App\Http\Controllers\Cart\Facades\Cart::discount())); ?></p>
            </div>
        </li>
        <li>
            <a href="<?php echo e(route('cart')); ?>" class="btn theme-btn w-100">ادامه فرایند خرید <i class="la la-arrow-left icon ml-1"></i></a>
        </li>
    </ul>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/header-cart.blade.php ENDPATH**/ ?>