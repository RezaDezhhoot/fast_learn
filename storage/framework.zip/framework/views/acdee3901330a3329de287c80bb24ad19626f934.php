<!DOCTYPE html>
<html lang="fa">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.includes.site.head', [])->html();
} elseif ($_instance->childHasBeenRendered('CBlmdpX')) {
    $componentId = $_instance->getRenderedChildComponentId('CBlmdpX');
    $componentTag = $_instance->getRenderedChildComponentTagName('CBlmdpX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CBlmdpX');
} else {
    $response = \Livewire\Livewire::mount('site.includes.site.head', []);
    $html = $response->html();
    $_instance->logRenderedChild('CBlmdpX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <body>







        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.includes.site.header', [])->html();
} elseif ($_instance->childHasBeenRendered('rogjGWu')) {
    $componentId = $_instance->getRenderedChildComponentId('rogjGWu');
    $componentTag = $_instance->getRenderedChildComponentTagName('rogjGWu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rogjGWu');
} else {
    $response = \Livewire\Livewire::mount('site.includes.site.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('rogjGWu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.includes.site.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('aVJry0W')) {
    $componentId = $_instance->getRenderedChildComponentId('aVJry0W');
    $componentTag = $_instance->getRenderedChildComponentTagName('aVJry0W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aVJry0W');
} else {
    $response = \Livewire\Livewire::mount('site.includes.site.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('aVJry0W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <div id="scroll-top">
            <i class="la la-arrow-up" title="برو بالا"></i>
        </div>
    </body>
    <?php echo $__env->make('site.includes.site.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/site/layouts/site/site.blade.php ENDPATH**/ ?>