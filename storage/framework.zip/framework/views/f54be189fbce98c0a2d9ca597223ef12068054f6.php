<head>
    <?php echo \Livewire\Livewire::styles(); ?>

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>

    <?php echo JsonLd::generate(); ?>

    <!-- Google fonts -->
    <script src="https://cdn.plyr.io/3.6.12/plyr.js"></script>
    <link rel="stylesheet" href="https://cdn.plyr.io/3.6.12/plyr.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com/" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800&amp;display=swap" rel="stylesheet" />

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="<?php echo e(asset($logo)); ?>" />

    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('site/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/line-awesome.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/owl.theme.default.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/bootstrap-select.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/fancybox.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/tooltipster.bundle.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/animated-headline.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('site/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/jdate/persianDatepicker-default.css')); ?>" />
    <!-- end inject -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>

</head>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/site/includes/site/head.blade.php ENDPATH**/ ?>