<?php foreach($attributes->onlyProps(['icon','label','active']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['icon','label','active']); ?>
<?php foreach (array_filter((['icon','label','active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li class="menu-item menu-item-submenu <?php echo e($active  ? 'menu-item-open' : ''); ?>" aria-haspopup="true" data-menu-toggle="hover">
    <a href="javascript:;" class="menu-link menu-toggle">
        <i class="menu-icon <?php echo e($icon); ?>"></i>
        <span class="menu-text"><?php echo e($label); ?></span>
        <i class="menu-arrow"></i>
    </a>
    <div class="menu-submenu" style="<?php echo e($active ? '' : 'display: none; overflow: hidden;'); ?>">
        <i class="menu-arrow"></i>
        <ul class="menu-subnav">
            <li class="menu-item menu-item-parent " aria-haspopup="true">
                <span class="menu-link">
                    <span class="menu-text"><?php echo e($label); ?></span>
                </span>
            </li>
            <?php echo e($slot); ?>

        </ul>
    </div>
</li>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/admin/menu-group.blade.php ENDPATH**/ ?>