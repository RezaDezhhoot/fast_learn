<?php foreach($attributes->onlyProps(['item','show_details'=>true]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['item','show_details'=>true]); ?>
<?php foreach (array_filter((['item','show_details'=>true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div <?php echo e($attributes); ?>>
    <div class="card card-item card-preview" data-tooltip-content="#<?php echo e($item['slug'].$item['id']); ?>">
        <div class="card-image">
            <a href="<?php echo e(route('course',$item['slug'])); ?>" class="d-block">
                <img class="card-img-top" src="<?php echo e(asset($item['image'])); ?>" alt="<?php echo e($item['title']); ?>" />
            </a>
            <div class="course-badge-labels">
                <div class="course-badge"><?php echo e($item->status_label); ?></div>
                <?php if($item['has_reduction'] && $item['base_price'] > 0): ?>
                    <div class="course-badge blue">٪<?php echo e($item->reduction_percent); ?>-</div>
                <?php endif; ?>
                <div class="course-badge green"><?php echo e($item->type_label); ?></div>
            </div>
        </div>
        <!-- end card-image -->
        <div class="card-body">
            <h6 class="ribbon ribbon-blue-bg fs-14 mb-3">
                <a href="<?php echo e(route('courses',['category'=>$item->category->slug])); ?>"><?php echo e($item->category->title); ?></a>
            </h6>
            <h5 class="card-title"><a href="<?php echo e(route('course',$item['slug'])); ?>"><?php echo e($item['title']); ?></a></h5>
            <?php if(!is_null($item->teacher)): ?>
            <p class="card-text"><a href="<?php echo e(route('teacher',$item->teacher->id)); ?>"><?php echo e($item->teacher->user->name ?? ''); ?></a></p>
            <?php endif; ?>
            <div class="rating-wrap d-flex align-items-center py-2">
                <div class="review-stars">
                    <span class="rating-number"><?php echo e($item->score); ?></span>
                    <?php for($i=1; $i<=5;$i++): ?> <?php if($i <=$item->score): ?>
                        <span class="la la-star"></span>
                        <?php else: ?>
                        <span class="la la-star-o"></span>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <span class="rating-total pl-1">(<?php echo e($item->sold_count); ?>)</span>
            </div>
            <!-- end rating-wrap -->
            <div class="d-flex justify-content-between align-items-center">
                <?php if($item['has_reduction'] && $item['base_price'] > 0): ?>
                <p class="card-price text-black font-weight-bold"><?php echo e(number_format($item['price'])); ?> تومان
                    <span class="before-price font-weight-medium"><?php echo e(number_format($item['base_price'])); ?> تومان</span>
                </p>
                <?php elseif($item['base_price'] == 0 || $item['price'] == 0): ?>
                <p class="card-price text-black font-weight-bold">
                    رایگان
                </p>
                <?php else: ?>
                <p class="card-price text-black font-weight-bold">
                    <?php echo e(number_format($item['price'])); ?> تومان
                </p>
                <?php endif; ?>
            </div>
        </div>
        <!-- end card-body -->
        <?php if($show_details): ?>
            <div class="tooltip_templates">
            <div id="<?php echo e($item['slug'].$item['id']); ?>" wire:ignore>
                <div class="card card-item">
                    <div class="card-body">
                        <?php if(!is_null($item->teacher)): ?>
                            <p class="card-text pb-2">مدرس <a href="<?php echo e(route('teacher',$item->teacher->id)); ?>"><?php echo e($item->teacher->user->name ?? ''); ?></a></p>
                        <?php endif; ?>
                        <h5 class="card-title pb-1"><a href="<?php echo e(route('course',$item['slug'])); ?>"><?php echo e($item['title']); ?></a></h5>
                        <div class="d-flex align-items-center pb-1">
                            <h6 class="ribbon fs-14 mr-2"><?php echo e($item->status_label); ?></h6>
                            <p class="text-success fs-14 font-weight-medium"><span class="font-weight-bold pl-1"><?php echo e($item->updated_at->diffForHumans()); ?></span> به روز <span class="font-weight-bold pl-1">شد</span></p>
                        </div>
                        <ul class="generic-list-item generic-list-item-bullet generic-list-item--bullet d-flex align-items-center fs-14">
                            <li><?php echo e($item->hours); ?> ساعت در کل</li>
                            <li>همه مراحل</li>
                        </ul>
                        <p class="card-text pt-1 fs-14 lh-22">
                            <?php echo $item->short_body; ?>

                        </p>
                    </div>
                </div><!-- end card -->
            </div>
        </div>
        <?php endif; ?>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/courses/course-box.blade.php ENDPATH**/ ?>