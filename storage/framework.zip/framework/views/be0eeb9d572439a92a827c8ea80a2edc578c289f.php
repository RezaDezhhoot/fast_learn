<div>
    <div class="logo-box  px-4">
        <a href="<?php echo e(route('home')); ?>" class="logo mx-auto"><img class="logo-size" src="<?php echo e(asset($logo)); ?>" alt="لوگو" /></a>
    </div>
    <hr>
    
    <ul class="generic-list-item off-canvas-menu-list pt-2 pb-2 border-bottom border-bottom-gray">
        <li>
            <a href="<?php echo e(route('home')); ?>">صفحه اصلی</a>
        </li>
        <li>
            <a href="<?php echo e(route('courses')); ?>">دوره های آموزشی</a>
        </li>
        <li>
            <a href="<?php echo e(route('articles')); ?>">مقالات </a>
        </li>
        <li>
            <a href="<?php echo e(route('cart')); ?>">سبد خرید </a>
        </li>
        <li>
            <a href="<?php echo e(route('about')); ?>">درباره ما </a>
        </li>
        <li>
            <a href="<?php echo e(route('contact')); ?>">ارتباط با ما </a>
        </li>
    </ul>
    <?php if(auth()->guard()->check()): ?>
        <h2 class="off-canvas-menu-heading text-right pt-4">پنل کاربری</h2>
        <ul class="generic-list-item off-canvas-menu-list pt-2 pb-2 border-bottom border-bottom-gray">
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>">  مدیریت </a>
            </li>
            <?php endif; ?>
            <li>
                <a href="<?php echo e(route('user.courses')); ?>">  دوره های من </a>
            </li>
            <li>
                <a href="<?php echo e(route('user.dashboard')); ?>">  داشبورد </a>
            </li>
            <li>
                <a href="<?php echo e(route('user.profile')); ?>">  پروفایل </a>
            </li>
            <li>
                <a href="<?php echo e(route('logout')); ?>">  خروج </a>
            </li>
        </ul>
    <?php else: ?>
        <div class="btn-box px-4 pt-5 text-center">
            <a href="<?php echo e(route('auth')); ?>" class="btn theme-btn theme-btn-sm theme-btn-transparent"><i class="la la-sign-in mr-1"></i>ورود </a>
            <span class="fs-15 font-weight-medium d-inline-block mx-2">یا</span>
            <a href="<?php echo e(route('auth',['action'=>'register'])); ?>" class="btn theme-btn theme-btn-sm shadow-none"><i class="la la-plus mr-1"></i> ثبت نام</a>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/header-list-responsive.blade.php ENDPATH**/ ?>