<?php foreach($attributes->onlyProps(['categories','arrow' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['categories','arrow' => false]); ?>
<?php foreach (array_filter((['categories','arrow' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route('courses',['category'=>$item['slug']])); ?>"><?php echo e($item['title']); ?>

            <?php if(!empty($item['sub_categories'])): ?>
                <?php if($arrow): ?>
                    <i class="la la-angle-left"></i>
                <?php endif; ?>
            <?php endif; ?>
        </a>
        <?php if(sizeof($item['sub_categories']) > 0): ?>
            <ul class="sub-menu">
                <?php $__currentLoopData = $item['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('courses',['category'=>$value])); ?>"><?php echo e($item['sub_categories_title'][$key]); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/header-categories.blade.php ENDPATH**/ ?>