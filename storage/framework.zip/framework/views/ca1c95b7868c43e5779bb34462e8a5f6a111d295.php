<?php foreach($attributes->onlyProps(['class' => 'flex-grow-1 mr-3']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['class' => 'flex-grow-1 mr-3']); ?>
<?php foreach (array_filter((['class' => 'flex-grow-1 mr-3']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<form method="get" wire:submit.prevent="search" class="<?php echo e($class); ?>">
    <div class="form-group mb-0">
        <input class="form-control form--control pl-3" wire:model.defer="q" type="text" name="search" placeholder="هر چیزی را جستجو کنید" />
        <span wire:click="search" class="la la-search search-icon"></span>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/search-box.blade.php ENDPATH**/ ?>