<?php foreach($attributes->onlyProps(['id', 'label', 'required' => false, 'help', 'file' , 'type' => 'file', 'disable'=>false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'label', 'required' => false, 'help', 'file' , 'type' => 'file', 'disable'=>false]); ?>
<?php foreach (array_filter((['id', 'label', 'required' => false, 'help', 'file' , 'type' => 'file', 'disable'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <div class="form-group col-12">
        <label for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
        <?php if(!$disable): ?>
        <div class="input-group">
            <input type="text" <?php echo e($attributes->wire('model')); ?> id="<?php echo e($id); ?>" <?php echo $attributes->merge(['class'=>
            'form-control']); ?> name="image"
            aria-label="Image" aria-describedby="button-image"
            x-data
            x-init="$('#<?php echo e($id); ?>').on('change', function () {alert(2); $dispatch('input', $(this).val()) })"
            >
            <div class="input-group-append">
                <button <?php echo e($disable ? 'disabled' : ''); ?> class="btn btn-outline-secondary" type="button"
                    id="button-<?php echo e($id); ?>">انتخاب</button>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php if(gettype($file) == 'string'): ?>
    <div class="form-group col-12">
        <?php $__currentLoopData = explode(',', $file); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e(asset($item)); ?>" alt="<?php echo e($id); ?>" width="120px" height="100px" class="mr-1 mb-1 imglist"
            style="border-radius: 5px" />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>


</div>

<?php $__env->startPush('scripts'); ?>
<script>
    var id , input , input_id;
        document.addEventListener("DOMContentLoaded", function() {

            document.getElementById('button-<?php echo e($id); ?>').addEventListener('click', (event) => {
                event.preventDefault();
                id = event.target.id;
                input_id = id.replace("button-", '');
                input = document.getElementById(input_id);
                window.open('/file-manager/fm-button', 'fm', 'width=1400,height=800');
            });
        });


        // set file link

        function fmSetLink($url) {
            input.value = $url;
            window.livewire.find('<?php echo e($_instance->id); ?>').set(input_id, $url);
        }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/admin/forms/lfm-standalone.blade.php ENDPATH**/ ?>