<?php foreach($attributes->onlyProps(['id', 'label' , 'data' , 'required' => false , 'help' => false , 'value' => false,'with' => 12 ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'label' , 'data' , 'required' => false , 'help' => false , 'value' => false,'with' => 12 ]); ?>
<?php foreach (array_filter((['id', 'label' , 'data' , 'required' => false , 'help' => false , 'value' => false,'with' => 12 ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="form-group col-md-<?php echo e($with); ?> col-12">
    <label for="<?php echo e($id); ?>"> <?php echo e($label); ?> </label>
    <select <?php echo e($attributes); ?>  id="<?php echo e($id); ?>"  <?php echo $attributes->merge(['class'=> 'form-control']); ?>>
        <option value="">انتخاب</option>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value ? $item : $key); ?>"><?php echo e($item); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($help): ?>
        <small class="text-info"><?php echo e($help); ?></small>
    <?php endif; ?>
    <?php $__errorArgs = [$id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger d-block"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/admin/forms/dropdown.blade.php ENDPATH**/ ?>