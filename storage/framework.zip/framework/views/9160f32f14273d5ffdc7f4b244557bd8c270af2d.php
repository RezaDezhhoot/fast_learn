<?php foreach($attributes->onlyProps(['icon','label','active']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['icon','label','active']); ?>
<?php foreach (array_filter((['icon','label','active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li class="menu-item <?php echo e($active  ? 'menu-item-active' : ''); ?>" aria-haspopup="true" data-menu-toggle="hover">
    <a <?php echo $attributes; ?> class="menu-link">
        <i class="menu-icon <?php echo e($icon); ?>">
            <span></span>
        </i>
        <span class="menu-text"><?php echo e($label); ?></span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/admin/menu-item.blade.php ENDPATH**/ ?>