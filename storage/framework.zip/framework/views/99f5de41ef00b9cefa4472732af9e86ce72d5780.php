<?php foreach($attributes->onlyProps(['id', 'label' , 'required' => false,'help' => false ,'with' => 12]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'label' , 'required' => false,'help' => false ,'with' => 12]); ?>
<?php foreach (array_filter((['id', 'label' , 'required' => false,'help' => false ,'with' => 12]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    <div class="form-group col-12 col-md-<?php echo e($with); ?>">
        <label for="<?php echo e($id); ?>">
            <input type="checkbox" id="<?php echo e($id); ?>" <?php echo e($attributes); ?>>
            <?php echo e($label); ?>

        </label>
        <br>
        <?php if($help): ?>
            <small class="text-info"><?php echo e($help); ?></small>
        <?php endif; ?>
    </div>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/admin/forms/checkbox.blade.php ENDPATH**/ ?>