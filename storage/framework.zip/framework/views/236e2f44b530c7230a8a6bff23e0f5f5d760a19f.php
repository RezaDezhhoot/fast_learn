<ul>
    <li>
        <a href="<?php echo e(route('home')); ?>">صفحه اصلی </a>
    </li>
    <li>
        <a href="<?php echo e(route('courses')); ?>">دوره های آموزشی </a>
    </li>
    <li>
        <a href="<?php echo e(route('articles')); ?>">مقالات </a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/components/site/header-list.blade.php ENDPATH**/ ?>