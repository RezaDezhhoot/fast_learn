<!DOCTYPE html>
<html lang="fa">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.includes.site.head', [])->html();
} elseif ($_instance->childHasBeenRendered('ViZON0a')) {
    $componentId = $_instance->getRenderedChildComponentId('ViZON0a');
    $componentTag = $_instance->getRenderedChildComponentTagName('ViZON0a');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ViZON0a');
} else {
    $response = \Livewire\Livewire::mount('site.includes.site.head', []);
    $html = $response->html();
    $_instance->logRenderedChild('ViZON0a', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<body>







<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.includes.client.header', [])->html();
} elseif ($_instance->childHasBeenRendered('yhqJWca')) {
    $componentId = $_instance->getRenderedChildComponentId('yhqJWca');
    $componentTag = $_instance->getRenderedChildComponentTagName('yhqJWca');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yhqJWca');
} else {
    $response = \Livewire\Livewire::mount('site.includes.client.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('yhqJWca', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<section class="dashboard-area">
    <?php echo $__env->make('site.includes.client.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="dashboard-content-wrap">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</section>
<div id="scroll-top">
    <i class="la la-arrow-up" title="برو بالا"></i>
</div>
</body>
<?php echo $__env->make('site.includes.site.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\xampp\htdocs\fast_learn\resources\views/site/layouts/client/client.blade.php ENDPATH**/ ?>